const mongoose = require('mongoose');

const classSchema = new mongoose.Schema({
  class_id: String,
  class_name: String,
  subject: String,
  teacher_id: String,
  semester: String,
});

module.exports = mongoose.model('Class', classSchema);
