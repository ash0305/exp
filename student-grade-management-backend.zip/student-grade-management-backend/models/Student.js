const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  student_id: String,
  name: String,
  email: String,
  enrollment_year: Number,
  major: String,
});

module.exports = mongoose.model('Student', studentSchema);
