const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
// const User = require('./models/User');
const Student = require('./models/Student');
const Class = require('./models/Class');
const Grade = require('./models/Grade');
const jwt = require('jsonwebtoken');
const app = express();
const PORT = 5000;

app.use(express.json());
app.use(cors());

// MongoDB connection
mongoose.connect('mongodb+srv://hs1415526:In1SBoQkdtefDvzW@cluster0.not9e.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
    console.log('Connected to MongoDB');
  }).catch((error) => {
    console.error('MongoDB connection error:', error);
  });

// API Endpoints
// User Registration
app.post('/register', async (req, res) => {
    const { email, password, role } = req.body;
    try {
      const newUser = new User({ email, password, role });
      await newUser.save();
      res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });


  // User Login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await User.findOne({ email });
      if (!user || !(await user.comparePassword(password))) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      const token = jwt.sign({ id: user._id, role: user.role }, 'your_jwt_secret');
      res.json({ token });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
// Create Student
app.post('/students', async (req, res) => {
    try {
      const newStudent = new Student(req.body);
      await newStudent.save();
      res.status(201).json(newStudent);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  app.get('/students', async (req, res) => {
    try {
      const students = await Student.find();
      res.json(students);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

// Create Class
app.post('/classes', async (req, res) => {
  const newClass = new Class(req.body);
  await newClass.save();
  res.status(201).json(newClass);
});

// Get all Classes
app.get('/classes', async (req, res) => {
  const classes = await Class.find();
  res.json(classes);
});


// Grades API
app.post('/grades', async (req, res) => {
    const newGrade = new Grade(req.body);
    await newGrade.save();
    res.status(201).json(newGrade);
  });
  
  app.get('/grades', async (req, res) => {
    const grades = await Grade.find();
    res.json(grades);
  });
// Server listening
app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});
