const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
  student_id: String,
  class_id: String,
  assignment: String,
  grade: Number,
});

module.exports = mongoose.model('Grade', gradeSchema);
